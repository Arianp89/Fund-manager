from config import API_TOKEN 
from telebot.types import ReplyKeyboardMarkup, ReplyKeyboardRemove,InlineKeyboardMarkup, InlineKeyboardButton,KeyboardButton 
import telebot 
import logging
from handler.fun import *
from handler.bot_commands import commands
from handler.admin_button import admin_button
from handler.command import *
from handler.call_back import *





telebot.apihelper.API_URL = 'http://tapi.bale.ai/bot{0}/{1}' 
bot=telebot.TeleBot(API_TOKEN)




#____________________________________LOGG_______________________________________

# logging.basicConfig("level=logging.INFO, filename='project.log', format='%(asctime)s - %(levelname)s - %(message)s")

#____________________________________LISENER_____________________________________


def listener(messages):
    for m in messages: 
        # print(m) 
        if m.content_type == "text": 
            print(f"{m.chat.first_name} [{str(m.chat.id)}]: {m.text}") 
            logging.info(f"{m.chat.first_name} [{str(m.chat.id)}]: {m.text}") 
        elif m.content_type == "photo": 
            print(f"{m.chat.first_name} [{str(m.chat.id)}]: New photo recieved") 
            logging.info(f"{m.chat.first_name} [{str(m.chat.id)}]: New photo recieved") 
        elif m.content_type == "document": 
            print(f"{m.chat.first_name} [{str(m.chat.id)}]: New document recieved") 
            logging.info(f"{m.chat.first_name} [{str(m.chat.id)}]: New document recieved") 
        elif m.content_type == "voice":
            print(f"{m.chat.first_name} [{str(m.chat.id)}]: New voice recieved") 
            logging.info(f"{m.chat.first_name} [{str(m.chat.id)}]: New voice recieved") 
bot.set_update_listener(listener) 
            

#____________________________________MAKE-BOT____________________________________


bot_command = commands(bot)
admin_buttons = admin_button(bot)

@bot.message_handler(commands=['start'])
def start_handler(message):
    bot_command.start(message)


@bot.message_handler(commands=['help'])
def help_handler(message):
    bot_command.help(message)

@bot.message_handler(commands=[password_get_access1])
def add_admin_handler(message):
    bot_command.add_admin_access1(message)


#____________________________________BUTTON______________________________________


@bot.message_handler(func=lambda message: message.text == "گرفتن بکآپ")
def get_backup_handler(message):
    admin_buttons.get_backup(message)

@bot.message_handler(func=lambda message: message.text == "دریافت لینک")
def get_link_handler(message):
    admin_buttons.family_link(message , 'make_link')


#____________________________CALLS_______________________

@bot.callback_query_handler(func=lambda call: True)
def all_callback_query_handler(call):
    call_hanler = call_back(bot , call)
    data = call.data
    print(f'call={call.message.from_user.first_name} [{call.message.chat.id}]:{data}')

    if data.startswith("add-access1"):
        call_hanler.add_access1(data)

    elif data.startswith("go"):
        call_hanler.go(data)



#________________________________ALL-MESSAGE__________________________
@bot.message_handler(func=lambda message: True)
def all_message_handler(message):
    bot_command.all_message(message)


print('code running...') 
logging.info('code running...') 
bot.infinity_polling() 
            
'code write it by:'
'arian panahi  github id : http://github.com/arianp89'  
            